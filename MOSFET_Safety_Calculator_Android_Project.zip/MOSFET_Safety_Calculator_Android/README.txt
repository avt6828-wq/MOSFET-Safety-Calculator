MOSFET Safety Calculator - Android project

This is an Android Studio project that packages your calculator HTML inside an offline Android WebView app.
App name: MOSFET Safety Calculator
Application ID: com.example.mosfetsafetycalculator

BUILD APK USING GITHUB (can be done from an Android phone):
1. Extract this ZIP.
2. Create a new GitHub repository in your browser.
3. Upload all files and folders from this project into the repository (keep the .github/workflows/build-apk.yml file).
4. Open the repository's Actions tab.
5. Select "Build Android APK" and tap "Run workflow" (or wait for the automatic build after pushing to main).
6. When the run completes, open it and download the artifact named "MOSFET-Safety-Calculator-APK".
7. Extract the downloaded artifact ZIP; app-debug.apk is the installable APK. Android may ask you to allow installation from that source.

For local build in Android Studio:
- Open this folder as a project.
- Use JDK 17 and Android SDK 35.
- Run: gradle assembleDebug
- APK output: app/build/outputs/apk/debug/app-debug.apk

Engineering note:
The calculator implements the supplied 80% Vds and 40% Pd thresholds. Its verdict is only a screening aid, not proof that a MOSFET is completely safe. Verify SOA, switching transients, gate drive, thermal design, and datasheet conditions before relying on a real circuit.
